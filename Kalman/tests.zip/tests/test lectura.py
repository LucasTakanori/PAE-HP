import matplotlib.pyplot as plt
import kalmanv3_test_validation_mobile as Kalman
import numpy as np

# Extract velocity: MODE=0, extract position: MODE=1
MODE = 1

#Read file 90D.txt or 90E.txt
file = "90D.txt"
f = open(file, 'r')

texto = ""
for linea in f:
    texto = texto + linea

linea = ""
data = []
cont = 0
for i in texto:
    if i != "}":
        linea = linea + i
    else:
        data.append(linea)
        linea = ""

clean = []
x = ""
lectura = False
for vector in data:
    for car in vector:
        if car == ":" or (lectura):
            lectura = True
            x = x + car
        if car == ",":
            lectura = False
            clean.append(x)
            x = ""

clean = clean[1:]
vel = []
cont = 0
for num in clean:
    cont += 1
    # Se tiene que filtar la componente z del fichero
    if cont%4 == 3:
        vel.append(float(num[1:-1]))



fs = 250

t = np.arange(1/fs, len(vel)*1/fs+1/fs, 1/fs, dtype='double')

# Integration of noisy measurements
pos = [0.]
cont = 0
for sample in vel:
    value = pos[-1] + (float(sample)*1/fs)*180/3.14
    pos.append(value)
    cont += 1
pos = pos[1:]


# Filtrado de las muestras
correction_v = []
correction_p = []
k = Kalman.KalmanPhone(fs, 0, 0)

for sample in vel:
    k.filter(sample)
    correction_v.append(k.get_velocity()*(180/3.14))
    correction_p.append(k.get_position()*(180/3.14))




plt.figure()
if MODE == 0:
    plt.plot(t, vel,'k-',label='noisy measurements')
    plt.plot(t, correction_v,'r-',label='a posteri estimate')
    plt.xlabel('Time')
    plt.ylabel('Angular Velocity (Degrees/s)')
else:
    plt.plot(t, pos,'k-',label='noisy measurements')
    plt.plot(t, correction_p,'r-',label='a posteri estimate')
    plt.xlabel('Time')
    plt.ylabel('Angular Position (Degrees)')

plt.legend()
plt.title('Estimate vs. iteration step', fontweight='bold')
plt.show()
