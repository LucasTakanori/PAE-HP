import matplotlib.pyplot as plt
import kalman2d as Kalman
import readfile as rf
import numpy as np

read = rf.ReadFile()
read.read_file("gyro 57,04.txt")
gyro = read.get_data()

read.read_file("encoder 57,04.txt")
encoder = read.get_data()

read.read_file("time 57,04.txt")
time = read.get_data()

fs = []
ind=-1
for t in time:
    fs.append(1/abs((time[ind]-t)*0.001))
    ind+=1


pe = [0]

ind=0
for sample in encoder:
    pe.append(pe[ind]+sample*1/fs[ind])
    ind+=1
pe = pe[1:]

pg = [0.0]
ind=0
for sample in gyro:
    pg.append(pg[-1] + (sample*1/fs[ind]))
    ind+=1
pg = pg[1:]

correction_v = []
correction_p = []
k = Kalman.Kalman(fs, 0, 0)
ind = 0
for sample in encoder:
    k.filter(sample, pe[ind], encoder[ind])
    correction_v.append(k.get_velocity())
    correction_p.append(k.get_position())

#INTEGRATION correction_v -> real position
alp = 0
real_pos = [0]
i = 0
while i < len(time):
    real_pos.append(real_pos[-1] + correction_v[i]/fs[i])
    i += 1
real_pos = real_pos[1:]

#t = np.arange(1/fs, len(gyro)*1/fs+1/fs, 1/fs, dtype='double')
print(real_pos[-1], pg[-1], pe[-1])

fig, axs = plt.subplots(2)


axs[0].set_title('Angular Position', fontweight = "bold")
axs[1].set_title('Angular Velocity', fontweight = "bold")

axs[0].plot(time, pe, 'g', label = "Encoder Measurements")
axs[0].plot(time, real_pos, 'b', label = "Kalman Output")
axs[0].plot(time, pg, 'r', label = "Gyro Measurements")
axs[0].legend()
axs[0].set(ylabel='Angular Position (Degrees)')

axs[1].plot(time, encoder, 'g', label = "Encoder Measurements")
axs[1].plot(time, gyro, 'r', label = "Gyro Measurements")
axs[1].plot(time, correction_v, 'b', label = "Kalman Output")
axs[1].legend()
axs[1].set(xlabel='Time', ylabel='Angular Velocity (Degrees/s)')

plt.show()
