from filterpy.kalman import KalmanFilter
from filterpy.common import Q_discrete_white_noise
import numpy as np
import matplotlib.animation as animation

class Kalman: 

    def __init__(self, fs, omega0):
        self.fs = fs
        self.t = 0
        self.ind = 0
        self.encoder = .0
        self.state = omega0
        k = KalmanFilter (dim_x=1, dim_z=1)                       #initialization
        k.x = omega0                                              #intial state (position and velocity)
        k.F = np.array(1.0)                                       #define transition matrix
        k.H = np.array(1.0)                                       #define measurement matrix
        k.P = np.array(0.1)                                     #define process covariance matrix
        k.R = np.array(0.01)                                    #define measurement noise matrix
        k.Q = np.array(1.5)                                     #define process noise matrix
        self.k = k                                                #define the kalman filter object


    def filter(self, measure, velocity):
        self.encoder = velocity
        if self.k.x==0:
            f1 = 0.0
        else:
            f1 = self.encoder/self.k.x
        self.k.F = np.array(f1)
        self.k.predict()
        self.k.update(measure)
        self.state = self.k.x
        self.t = round(1/self.fs[self.ind],5)
        self.ind += 1
        return self.state


    def get_velocity(self):
        return self.state
        