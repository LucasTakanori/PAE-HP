class ReadFile:

    def __init__(self):
        self.file = str()
        self.data = []

    def read_file(self, filename):
        self.data = []
        self.file = filename
        f = open(self.file, 'r')
        for row in f:
            self.data.append(float(row.strip('\n')))
    
    def get_data(self):
        return self.data
        