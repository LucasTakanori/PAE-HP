import matplotlib.pyplot as plt
import kalman1d as Kalman
import numpy as np
import readfile as rf

read = rf.ReadFile()
read.read_file("gyro 57,04.txt")
gyro = read.get_data()

read.read_file("encoder 57,04.txt")
encoder = read.get_data()

read.read_file("time 57,04.txt")
time = read.get_data()

fs = []
ind=-1
for t in time:
    fs.append(1/abs((time[ind]-t)*0.001))
    ind+=1


k = Kalman.Kalman(fs, 0.0)

ind = 0
correction = []
while ind < len(gyro):
    k.filter(gyro[ind], encoder[ind])
    correction.append(k.get_velocity)



fig, axs = plt.subplots(2)


axs[0].set_title('Angular Position', fontweight = "bold")
axs[1].set_title('Angular Velocity', fontweight = "bold")

#axs[0].plot(time, encoder, 'r', label = "Measurements")
axs[0].plot(time, correction, 'b', label = "Kalman Output")
axs[0].legend()
axs[0].set(ylabel='Angular Position (Degrees)')

axs[1].plot(time, gyro, 'r', label = "Measurements")
#axs[1].plot(time, correction_v, 'b', label = "Kalman Output")
axs[1].legend()
axs[1].set(xlabel='Time', ylabel='Angular Velocity (Degrees/s)')

plt.show()
