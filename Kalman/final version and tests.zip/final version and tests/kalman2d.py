from filterpy.kalman import KalmanFilter
from filterpy.common import Q_discrete_white_noise
import numpy as np
import matplotlib.animation as animation

class Kalman: 

    def __init__(self, fs, alpha0, omega0):
        self.fs = fs
        self.t = 0
        self.ind = 0
        self.encoder = [.0 , .0]
        self.state = [alpha0, omega0]
        k = KalmanFilter (dim_x=2, dim_z=2)                       #initialization
        k.x = np.array([alpha0, omega0])                          #intial state (position and velocity)
        k.F = np.array([[1.,(1/76.17)],
                        [0.,1.]])                                 #define transition matrix
        k.H = np.array([[1.,(1/76.17)],
                        [0.,1.]])                                 #define measurement matrix
        k.P = np.array([[1000.,    0.],
                        [   0., 1000.] ])                         #define covariance matrix
        k.R = np.array([[0.000238,    0.],
                        [   0., 0.000238] ])                          #define measurement noise matrix
        k.Q = np.array([[0.00253,  0],
                        [0,  0.00253]])                               #define process noise matrix
        self.k = k                                                #define the kalman filter object

    def angular_vector(alpha, omega, t):
        alpha = alpha + omega*t
        return [alpha, omega]

    def filter(self, measure, position, velocity):
        self.encoder = [position, velocity]
        if self.k.x[0]==0:
            f1 = 0
            f2 = 0
        else:
            f1 = (self.encoder[0] + self.encoder[1]*self.t)/self.k.x[0]
            f2 = self.encoder[1]/self.k.x[1]
        self.k.F = np.array([[f1,    0.],
                             [   0., f2] ])
        self.k.predict()
        vector = [self.k.x[0] + measure*self.t, measure]
        self.k.update(vector)
        self.state = self.k.x
        self.t = round(1/self.fs[self.ind],5)
        self.ind += 1
        return self.state[1]

    def update_encoder(self, position, velocity):
        return [position, velocity]

    def get_position(self):
        return self.state[0]

    def get_velocity(self):
        return self.state[1]
