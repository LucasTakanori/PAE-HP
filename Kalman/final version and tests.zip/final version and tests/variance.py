import readfile as rf
import matplotlib.pyplot as plt

read = rf.ReadFile()
read.read_file("test1\gyro.txt")
gyro = read.get_data()

valid_data = gyro[500:]
mean = sum(valid_data)/len(valid_data)

cov = 0
for value in valid_data:
    cov += ((value - mean)**2)/len(valid_data)
print(mean, cov)
